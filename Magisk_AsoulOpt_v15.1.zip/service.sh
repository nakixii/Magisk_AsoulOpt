MODDIR=${0%/*}
while $(dumpsys window policy | grep mIsShowing | awk -F= '{print $2}'); do
    sleep 1
done

nohup $MODDIR/AsoulOpt &
echo "$(pidof AsoulOpt)" > /dev/cpuset/background/cgroup.procs
exit
