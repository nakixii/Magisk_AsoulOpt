if [ -d /data/adb/modules/unity_affinity_opt ]; then
    mv /data/adb/modules/unity_affinity_opt /data/adb/modules/asoul_affinity_opt
fi

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/AsoulOpt 0 0 0755
